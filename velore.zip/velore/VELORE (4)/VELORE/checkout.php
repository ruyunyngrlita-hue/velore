<?php
require_once __DIR__ . '/includes/config.php';

if (empty($_SESSION['cart'])) {
    flash('ตะกร้าของคุณว่างเปล่า', 'error');
    redirect('cart.php');
}

$errors = [];
$old = ['customer_name' => '', 'phone' => '', 'address' => ''];

// ---------- โหลดสินค้าในตะกร้า ----------
function load_cart_items($conn) {
    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    $items = [];
    while ($p = $res->fetch_assoc()) {
        $p['qty'] = $_SESSION['cart'][$p['id']];
        $items[] = $p;
    }
    return $items;
}

$items = load_cart_items($conn);

// ---------- บันทึกออเดอร์ ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $old['customer_name'] = trim($_POST['customer_name'] ?? '');
    $old['phone']         = trim($_POST['phone'] ?? '');
    $old['address']       = trim($_POST['address'] ?? '');

    if ($old['customer_name'] === '' || mb_strlen($old['customer_name']) > 150) {
        $errors[] = 'กรุณากรอกชื่อ-นามสกุล';
    }
    if (!preg_match('/^[0-9+\-\s]{9,20}$/', $old['phone'])) {
        $errors[] = 'กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง';
    }
    if ($old['address'] === '') {
        $errors[] = 'กรุณากรอกที่อยู่จัดส่ง';
    }

    if (!$errors) {
        try {
            $conn->begin_transaction();

            $total = 0;
            $lines = [];
            foreach ($items as $it) {
                // ล็อกแถวสินค้าเพื่อตรวจสต็อกล่าสุด
                $stmt = $conn->prepare('SELECT name, price, stock FROM products WHERE id = ? FOR UPDATE');
                $stmt->bind_param('i', $it['id']);
                $stmt->execute();
                $cur = $stmt->get_result()->fetch_assoc();

                if (!$cur || $cur['stock'] < $it['qty']) {
                    throw new RuntimeException('สินค้า "' . ($cur['name'] ?? $it['name']) . '" มีสต็อกไม่เพียงพอ');
                }
                $total += $cur['price'] * $it['qty'];
                $lines[] = ['id' => $it['id'], 'qty' => $it['qty'], 'price' => $cur['price']];
            }

            $stmt = $conn->prepare('INSERT INTO orders (customer_name, phone, address, total_price, status) VALUES (?, ?, ?, ?, \'pending\')');
            $stmt->bind_param('sssd', $old['customer_name'], $old['phone'], $old['address'], $total);
            $stmt->execute();
            $orderId = $conn->insert_id;

            $insItem = $conn->prepare('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)');
            $updStock = $conn->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
            foreach ($lines as $l) {
                $insItem->bind_param('iiid', $orderId, $l['id'], $l['qty'], $l['price']);
                $insItem->execute();
                $updStock->bind_param('ii', $l['qty'], $l['id']);
                $updStock->execute();
                log_stock($conn, (int)$l['id'], -(int)$l['qty'], 'sale', 'ออเดอร์ #' . $orderId);
            }

            $conn->commit();

            $_SESSION['cart'] = [];
            $_SESSION['last_order_id'] = $orderId;
            redirect('order_success.php');
        } catch (RuntimeException $ex) {
            $conn->rollback();
            $errors[] = $ex->getMessage();
        } catch (Throwable $ex) {
            $conn->rollback();
            $errors[] = 'เกิดข้อผิดพลาดในการบันทึกคำสั่งซื้อ กรุณาลองใหม่อีกครั้ง';
        }
    }
}

$total = 0;
foreach ($items as $it) {
    $total += $it['price'] * $it['qty'];
}

$pageTitle = 'สั่งซื้อสินค้า';
require __DIR__ . '/includes/header.php';
?>

<h1>ยืนยันการสั่งซื้อ</h1>

<?php foreach ($errors as $err): ?>
    <div class="alert alert-error"><?= e($err) ?></div>
<?php endforeach; ?>

<div class="checkout-layout">
    <form method="post" class="form-box">
        <?= csrf_field() ?>
        <h3 style="margin-top:0">ข้อมูลจัดส่ง</h3>

        <label for="customer_name">ชื่อ-นามสกุล</label>
        <input type="text" id="customer_name" name="customer_name" value="<?= e($old['customer_name']) ?>" required>

        <label for="phone">เบอร์โทรศัพท์</label>
        <input type="tel" id="phone" name="phone" value="<?= e($old['phone']) ?>" required>

        <label for="address">ที่อยู่จัดส่ง</label>
        <textarea id="address" name="address" required><?= e($old['address']) ?></textarea>

        <p style="margin-top:20px"><button class="btn" type="submit">ยืนยันสั่งซื้อ</button>
        <a class="btn btn-outline" href="cart.php">กลับไปตะกร้า</a></p>
    </form>

    <div class="form-box">
        <h3 style="margin-top:0">สรุปรายการ</h3>
        <?php foreach ($items as $it): ?>
            <div style="display:flex;justify-content:space-between;gap:10px;margin-bottom:8px">
                <span><?= e($it['name']) ?> &times; <?= (int)$it['qty'] ?></span>
                <span><?= money($it['price'] * $it['qty']) ?></span>
            </div>
        <?php endforeach; ?>
        <hr style="border:0;border-top:1px solid var(--line)">
        <div style="display:flex;justify-content:space-between;font-size:1.15rem">
            <strong>ยอดรวม</strong><strong><?= money($total) ?></strong>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
