<?php
require_once __DIR__ . '/includes/config.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();

if (!$p) {
    http_response_code(404);
    $pageTitle = 'ไม่พบสินค้า';
    require __DIR__ . '/includes/header.php';
    echo '<p>ไม่พบสินค้าที่ต้องการ <a href="index.php">กลับหน้าแรก</a></p>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $p['name'];
require __DIR__ . '/includes/header.php';
?>

<div class="two-col">
    <img src="<?= e(product_image($p['image'])) ?>" alt="<?= e($p['name']) ?>">
    <div>
        <span class="brand" style="text-transform:uppercase;letter-spacing:.1em;color:var(--muted)"><?= e($p['brand']) ?></span>
        <h1><?= e($p['name']) ?></h1>
        <?php if ($p['category_name']): ?>
            <p><a class="chip" href="index.php?cat=<?= (int)$p['category_id'] ?>"><?= e($p['category_name']) ?></a></p>
        <?php endif; ?>
        <p><strong>ส่วนผสมกลิ่น:</strong> <?= e($p['scent_notes']) ?></p>
        <p><?= nl2br(e($p['description'])) ?></p>
        <p class="price" style="font-size:1.6rem;color:var(--gold-dark);font-weight:600"><?= money($p['price']) ?></p>
        <p style="color:var(--muted)">คงเหลือ <?= (int)$p['stock'] ?> ชิ้น</p>

        <?php if ($p['stock'] > 0): ?>
            <form method="post" action="cart.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                <label for="qty">จำนวน</label>
                <input class="qty-input" id="qty" type="number" name="quantity" value="1" min="1" max="<?= (int)$p['stock'] ?>">
                <button class="btn" type="submit">เพิ่มลงตะกร้า</button>
            </form>
        <?php else: ?>
            <p class="badge-out">สินค้าหมด</p>
        <?php endif; ?>
        <p style="margin-top:20px"><a href="index.php">&larr; กลับไปเลือกสินค้า</a></p>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
