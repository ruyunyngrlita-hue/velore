<?php
require_once __DIR__ . '/includes/config.php';

$categories = get_categories($conn);
$selected = (int)($_GET['cat'] ?? 0);
$validIds = array_column($categories, 'id');
if (!in_array($selected, array_map('intval', $validIds), true)) {
    $selected = 0;
}

// ดึงสินค้า (กรองตามหมวดถ้าเลือก) พร้อมชื่อหมวด
$sql = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id';
if ($selected > 0) {
    $stmt = $conn->prepare($sql . ' WHERE p.category_id = ? ORDER BY p.id DESC');
    $stmt->bind_param('i', $selected);
} else {
    $stmt = $conn->prepare($sql . ' ORDER BY c.name IS NULL, c.name, p.id DESC');
}
$stmt->execute();
$result = $stmt->get_result();

// จัดกลุ่มสินค้าตามแนวกลิ่น (สินค้าไม่มีหมวดจะอยู่กลุ่ม "อื่น ๆ")
$grouped = [];
while ($row = $result->fetch_assoc()) {
    $grouped[$row['category_name'] ?? 'อื่น ๆ'][] = $row;
}

$selectedName = '';
foreach ($categories as $c) {
    if ((int)$c['id'] === $selected) $selectedName = $c['name'];
}

$pageTitle = $selectedName !== '' ? "น้ำหอมแนว $selectedName" : 'น้ำหอมนำเข้า';
require __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <h1>VELORE</h1>
    <p>น้ำหอมนำเข้าแท้ คัดสรรกลิ่นระดับโลกถึงมือคุณ</p>
    <div class="filter-bar">
        <a class="chip <?= $selected === 0 ? 'active' : '' ?>" href="index.php">ทั้งหมด</a>
        <?php foreach ($categories as $c): ?>
            <a class="chip <?= $selected === (int)$c['id'] ? 'active' : '' ?>" href="index.php?cat=<?= (int)$c['id'] ?>"><?= e($c['name']) ?></a>
        <?php endforeach; ?>
    </div>
</section>

<?php if (!$grouped): ?>
    <p style="text-align:center;color:var(--muted)">ยังไม่มีสินค้าในหมวดนี้</p>
<?php endif; ?>

<?php foreach ($grouped as $groupName => $list): ?>
    <h2><?= e($groupName) ?></h2>
    <div class="grid">
        <?php foreach ($list as $p): ?>
            <div class="card">
                <a href="product.php?id=<?= (int)$p['id'] ?>">
                    <img src="<?= e(product_image($p['image'])) ?>" alt="<?= e($p['name']) ?>">
                </a>
                <div class="card-body">
                    <span class="brand"><?= e($p['brand']) ?></span>
                    <a class="name" href="product.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a>
                    <span class="notes"><?= e($p['scent_notes']) ?></span>
                    <span class="price"><?= money($p['price']) ?></span>
                    <?php if ($p['stock'] > 0): ?>
                        <form method="post" action="cart.php">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                            <button class="btn" type="submit">เพิ่มลงตะกร้า</button>
                        </form>
                    <?php else: ?>
                        <span class="badge-out">สินค้าหมด</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
