# VELORE – ระบบร้านค้าออนไลน์น้ำหอมนำเข้า (PHP + MySQL) เวอร์ชัน 2

## ติดตั้งบน XAMPP (Windows)

1. เปิด **XAMPP Control Panel** แล้ว Start **Apache** และ **MySQL**
2. วางโฟลเดอร์ทั้งหมดไว้ที่ `C:\xampp\htdocs\VELORE`
3. เลือกอย่างใดอย่างหนึ่ง
   - **ติดตั้งใหม่ (ยังไม่มีข้อมูล):** เปิด http://localhost/VELORE/install.php
   - **มีฐานข้อมูล VELORE จากเวอร์ชันเก่าอยู่แล้ว:** เปิด http://localhost/VELORE/upgrade.php (ข้อมูลสินค้า/ออเดอร์เดิมไม่หาย)
   - หรือ phpMyAdmin → Import → `database.sql`
4. **ลบ `install.php` และ `upgrade.php` ทิ้งหลังใช้เสร็จ**
5. หน้าร้าน: http://localhost/VELORE/  ·  หลังร้าน: http://localhost/VELORE/admin/login.php
   - ผู้ใช้เริ่มต้น `admin` / `admin123` → ไปที่เมนู **เปลี่ยนรหัสผ่าน** ทันที

## ตั้งค่า
แก้ที่ `includes/config.php` : `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, `BASE_URL` (ชื่อโฟลเดอร์ใน htdocs), `LOW_STOCK` (จำนวนที่ถือว่าสินค้าใกล้หมด ค่าเริ่มต้น 5)
ถ้าใช้ `install.php` / `upgrade.php` ที่ MySQL มีรหัสผ่านหรือพอร์ตต่างจากค่าเริ่มต้น ให้แก้ค่าบนสุดของ `install.php` ด้วย

## ฐานข้อมูล
`categories`, `products` (มี `category_id`), `orders`, `order_items`, `stock_logs`, `admins`

## โครงสร้างไฟล์
```
VELORE/
├── database.sql / install.php / upgrade.php
├── index.php, product.php, cart.php, checkout.php, order_success.php   หน้าร้าน
├── includes/   config.php (DB + helper), auth.php (session/CSRF/login), header.php, footer.php
├── assets/     css/style.css, css/admin.css, placeholder.svg
├── uploads/    รูปสินค้า
└── admin/
    ├── login.php, logout.php, password.php
    ├── index.php          Dashboard (ยอดขาย, สินค้าใกล้หมด, ออเดอร์ล่าสุด)
    ├── products.php       รายการสินค้า ค้นหา/กรอง/แบ่งหน้า
    ├── product_form.php   เพิ่ม/แก้ไข + อัปโหลดรูป   product_delete.php
    ├── stock.php          ปรับสต็อก + ประวัติสต็อก
    ├── categories.php     จัดการหมวดหมู่
    ├── orders.php, order_view.php   คำสั่งซื้อ + เปลี่ยนสถานะ
    └── reports.php        รายงานยอดขาย รายวัน/เดือน/ปี + กราฟ + สินค้าขายดี
```

## หมายเหตุ
- ยอดขายในรายงาน/Dashboard นับเฉพาะออเดอร์สถานะ ชำระแล้ว / จัดส่งแล้ว / สำเร็จ
- ทุกการเปลี่ยนสต็อก (ขาย, ยกเลิกออเดอร์, ปรับเอง, แก้ในหน้าแก้ไขสินค้า) บันทึกลง `stock_logs`
- ยกเลิกออเดอร์ → คืนสต็อกอัตโนมัติ  เปิดกลับ → ตัดสต็อกอีกครั้ง (ถ้าของไม่พอจะเปิดไม่ได้)
- ล็อกอินผิด 5 ครั้งถูกล็อก 5 นาที, ไม่ใช้งาน 2 ชั่วโมงออกจากระบบอัตโนมัติ
- ก่อนขึ้นเว็บจริง: เปลี่ยนรหัสผ่านแอดมิน ใช้ HTTPS ตั้งรหัสผ่าน MySQL และลบส่วนแสดงรายละเอียด error ใน `config.php`
