<?php
require_once __DIR__ . '/config.php';
$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME . ' - น้ำหอมนำเข้า';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Noto+Sans+Thai:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a class="logo" href="<?= BASE_URL ?>/index.php">VELORE</a>
        <nav class="main-nav">
            <a href="<?= BASE_URL ?>/index.php">หน้าแรก</a>
            <?php foreach (get_categories($conn) as $cat): ?>
                <a href="<?= BASE_URL ?>/index.php?cat=<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></a>
            <?php endforeach; ?>
            <a class="cart-link" href="<?= BASE_URL ?>/cart.php">ตะกร้า <span class="cart-badge"><?= cart_count() ?></span></a>
        </nav>
    </div>
</header>
<main class="container">
<?= flash() ?>
