</main>
<footer class="site-footer">
    <div class="container">
        <p class="logo-small">VELORE</p>
        <p>น้ำหอมนำเข้าแท้ 100% &copy; <?= date('Y') ?> VELORE. All rights reserved.</p>
        <p><a href="<?= BASE_URL ?>/admin/login.php">สำหรับผู้ดูแลระบบ</a></p>
    </div>
</footer>
</body>
</html>
