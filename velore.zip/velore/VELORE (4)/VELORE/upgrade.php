<?php
// =====================================================
// VELORE - ตัวอัปเกรดฐานข้อมูลจากเวอร์ชัน 1 เป็นเวอร์ชัน 2
//   - เพิ่มตาราง categories และ stock_logs
//   - ย้ายคอลัมน์ products.scent_family -> products.category_id
//   - เพิ่มคอลัมน์ created_at ให้ products / admins
// ปลอดภัยที่จะรันซ้ำ (ข้ามขั้นตอนที่ทำไปแล้ว) ไม่ลบข้อมูลสินค้า/ออเดอร์
// รันที่ http://localhost/VELORE/upgrade.php แล้วลบไฟล์นี้ทิ้งหลังเสร็จ
// =====================================================
define('VELORE_SKIP_SCHEMA_CHECK', true);   // หน้านี้ใช้ซ่อมโครงสร้างเอง จึงไม่ต้องตรวจก่อน
require_once __DIR__ . '/includes/config.php';
unset($_SESSION['schema_ok']);              // ให้ตรวจใหม่หลังอัปเกรดเสร็จ

$steps = [];
$failed = false;

function col_exists(mysqli $c, string $table, string $col): bool {
    $stmt = $c->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?');
    $stmt->bind_param('ss', $table, $col);
    $stmt->execute();
    $stmt->bind_result($n);
    $stmt->fetch();
    $stmt->close();
    return $n > 0;
}

function fk_exists(mysqli $c, string $table, string $name): bool {
    $stmt = $c->prepare("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = ? AND constraint_name = ? AND constraint_type = 'FOREIGN KEY'");
    $stmt->bind_param('ss', $table, $name);
    $stmt->execute();
    $stmt->bind_result($n);
    $stmt->fetch();
    $stmt->close();
    return $n > 0;
}

function step(string $label, callable $fn): void {
    global $steps, $failed;
    if ($failed) {
        $steps[] = [$label, 'skip', 'ข้าม เพราะขั้นตอนก่อนหน้าล้มเหลว'];
        return;
    }
    try {
        $result = $fn();
        $steps[] = [$label, $result === false ? 'skip' : 'ok', $result === false ? 'ทำไปแล้ว ข้าม' : (is_string($result) ? $result : 'สำเร็จ')];
    } catch (Throwable $ex) {
        $failed = true;
        $steps[] = [$label, 'fail', $ex->getMessage()];
    }
}

step('สร้างตาราง categories', function () use ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS `categories` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(100) NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_category_name` (`name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
});

step('เพิ่มคอลัมน์ products.category_id', function () use ($conn) {
    if (col_exists($conn, 'products', 'category_id')) return false;
    $conn->query('ALTER TABLE `products` ADD COLUMN `category_id` INT UNSIGNED DEFAULT NULL AFTER `brand`');
});

step('ย้ายข้อมูล scent_family เป็น categories', function () use ($conn) {
    if (!col_exists($conn, 'products', 'scent_family')) return false;
    $conn->query("INSERT IGNORE INTO categories (name) SELECT DISTINCT scent_family FROM products WHERE scent_family IS NOT NULL AND scent_family <> ''");
    $conn->query('UPDATE products p JOIN categories c ON c.name = p.scent_family SET p.category_id = c.id');
    $conn->query('ALTER TABLE `products` DROP COLUMN `scent_family`');
    return 'ย้ายแล้ว และลบคอลัมน์ scent_family เดิมออก';
});

step('เพิ่มหมวดหมู่เริ่มต้น (ถ้ายังไม่มีหมวดใดเลย)', function () use ($conn) {
    $n = (int)$conn->query('SELECT COUNT(*) FROM categories')->fetch_row()[0];
    if ($n > 0) return false;
    $conn->query("INSERT INTO categories (name) VALUES ('Woody'),('Floral'),('Fresh'),('Oriental')");
});

step('เพิ่ม index และ foreign key ของ category_id', function () use ($conn) {
    if (fk_exists($conn, 'products', 'fk_products_category')) return false;
    $conn->query('ALTER TABLE `products` ADD KEY `idx_category` (`category_id`)');
    $conn->query('ALTER TABLE `products` ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL');
});

step('เพิ่มคอลัมน์ products.created_at', function () use ($conn) {
    if (col_exists($conn, 'products', 'created_at')) return false;
    $conn->query('ALTER TABLE `products` ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
});

step('เพิ่มคอลัมน์ admins.created_at', function () use ($conn) {
    if (col_exists($conn, 'admins', 'created_at')) return false;
    $conn->query('ALTER TABLE `admins` ADD COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
});

step('สร้างตาราง stock_logs', function () use ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS `stock_logs` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `product_id` INT UNSIGNED NOT NULL,
        `change_amount` INT NOT NULL,
        `type` ENUM('add','remove','adjust','sale','cancel') NOT NULL,
        `note` VARCHAR(255) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_log_product` (`product_id`),
        KEY `idx_log_created` (`created_at`),
        CONSTRAINT `fk_logs_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
});

step('บันทึกสต็อกตั้งต้นให้สินค้าที่ยังไม่มีประวัติ', function () use ($conn) {
    $conn->query("INSERT INTO stock_logs (product_id, change_amount, type, note)
        SELECT p.id, p.stock, 'add', 'สต็อกตั้งต้น (ตอนอัปเกรดระบบ)'
        FROM products p
        WHERE p.stock > 0 AND NOT EXISTS (SELECT 1 FROM stock_logs s WHERE s.product_id = p.id)");
    return 'เพิ่ม ' . $conn->affected_rows . ' รายการ';
});

step('เพิ่ม index ที่ orders (เพื่อให้รายงานเร็วขึ้น)', function () use ($conn) {
    $stmt = $conn->query("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'orders' AND index_name = 'idx_created'");
    if ((int)$stmt->fetch_row()[0] > 0) return false;
    $conn->query('ALTER TABLE `orders` ADD KEY `idx_created` (`created_at`), ADD KEY `idx_status` (`status`)');
});
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>อัปเกรด VELORE</title>
<style>
    body { font-family: system-ui, 'Noto Sans Thai', sans-serif; background:#faf6ef; color:#1f1b16; display:flex; justify-content:center; padding:48px 16px; }
    .box { background:#fff; border:1px solid #e7dfd0; border-radius:10px; padding:28px; max-width:640px; width:100%; }
    h1 { margin-top:0; letter-spacing:.2em; }
    ul { list-style:none; padding:0; }
    li { padding:8px 12px; border-radius:6px; margin:6px 0; background:#f6f2ea; }
    li.ok { background:#e4f3ea; } li.fail { background:#fbe9e7; color:#b3382c; }
    small { display:block; color:#7a6f60; }
    a.btn { display:inline-block; background:#a88a4e; color:#fff; padding:9px 18px; border-radius:6px; text-decoration:none; margin:6px 6px 0 0; }
</style>
</head>
<body>
<div class="box">
    <h1>VELORE UPGRADE</h1>
    <ul>
    <?php foreach ($steps as [$label, $state, $detail]): ?>
        <li class="<?= e($state) ?>"><?= e($label) ?><small><?= e($detail) ?></small></li>
    <?php endforeach; ?>
    </ul>
    <?php if ($failed): ?>
        <p style="color:#b3382c">การอัปเกรดหยุดกลางทาง ส่งข้อความสีแดงด้านบนมาให้ตรวจสอบ ข้อมูลเดิมไม่ได้ถูกลบ (ยกเว้นขั้นที่ขึ้นสำเร็จไปแล้ว) และกดรันซ้ำได้</p>
    <?php else: ?>
        <p>อัปเกรดเสร็จแล้ว <strong style="color:#b3382c">กรุณาลบไฟล์ upgrade.php และ install.php ออกจากโฟลเดอร์ VELORE</strong></p>
        <a class="btn" href="index.php">ไปหน้าร้าน</a>
        <a class="btn" href="admin/login.php">ไปหน้าแอดมิน</a>
    <?php endif; ?>
</div>
</body>
</html>
