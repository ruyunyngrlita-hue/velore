<?php
require_once __DIR__ . '/includes/config.php';

$orderId = (int)($_SESSION['last_order_id'] ?? 0);
if ($orderId <= 0) {
    redirect('index.php');
}

$stmt = $conn->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->bind_param('i', $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) {
    redirect('index.php');
}

$stmt = $conn->prepare(
    'SELECT oi.quantity, oi.price, p.name
     FROM order_items oi JOIN products p ON p.id = oi.product_id
     WHERE oi.order_id = ?'
);
$stmt->bind_param('i', $orderId);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$pageTitle = 'สั่งซื้อสำเร็จ';
require __DIR__ . '/includes/header.php';
?>

<div class="form-box" style="margin:0 auto">
    <h1>ขอบคุณสำหรับการสั่งซื้อ</h1>
    <p>หมายเลขคำสั่งซื้อของคุณคือ <strong>#<?= (int)$order['id'] ?></strong></p>
    <p>ผู้รับ: <?= e($order['customer_name']) ?> (<?= e($order['phone']) ?>)<br>
       ที่อยู่: <?= nl2br(e($order['address'])) ?></p>

    <table>
        <thead><tr><th>สินค้า</th><th>จำนวน</th><th class="num">ราคา</th></tr></thead>
        <tbody>
        <?php foreach ($items as $it): ?>
            <tr>
                <td><?= e($it['name']) ?></td>
                <td><?= (int)$it['quantity'] ?></td>
                <td class="num"><?= money($it['price'] * $it['quantity']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p class="cart-summary">ยอดรวม: <strong><?= money($order['total_price']) ?></strong></p>
    <p>ทางร้านจะติดต่อกลับเพื่อแจ้งรายละเอียดการชำระเงินและการจัดส่ง</p>
    <a class="btn" href="index.php">กลับหน้าแรก</a>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
