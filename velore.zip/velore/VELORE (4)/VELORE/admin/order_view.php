<?php
require_once __DIR__ . '/../includes/auth.php';
admin_required();

$statuses = order_statuses();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

// ---------- เปลี่ยนสถานะออเดอร์ ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $newStatus = $_POST['status'] ?? '';
    if (!isset($statuses[$newStatus])) {
        flash('สถานะไม่ถูกต้อง', 'error');
        redirect('order_view.php?id=' . $id);
    }

    try {
        $conn->begin_transaction();

        $stmt = $conn->prepare('SELECT status FROM orders WHERE id = ? FOR UPDATE');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $cur = $stmt->get_result()->fetch_assoc();
        if (!$cur) {
            throw new RuntimeException('ไม่พบคำสั่งซื้อ');
        }

        $toCancel = $newStatus === 'cancelled' && $cur['status'] !== 'cancelled';
        $reopen   = $cur['status'] === 'cancelled' && $newStatus !== 'cancelled';

        if ($toCancel || $reopen) {
            $stmt = $conn->prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $lines = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            foreach ($lines as $l) {
                $pid = (int)$l['product_id'];
                $qty = (int)$l['quantity'];

                $s = $conn->prepare('SELECT stock FROM products WHERE id = ? FOR UPDATE');
                $s->bind_param('i', $pid);
                $s->execute();
                $stock = (int)$s->get_result()->fetch_row()[0];

                if ($toCancel) {
                    $change = $qty;     // คืนสต็อก
                    $type = 'cancel';
                    $note = 'ยกเลิกออเดอร์ #' . $id;
                } else {
                    if ($stock < $qty) {
                        throw new RuntimeException('เปิดออเดอร์กลับไม่ได้ เพราะสต็อกสินค้าบางรายการไม่พอ (เหลือ ' . $stock . ' ต้องการ ' . $qty . ') กรุณาเติมสต็อกก่อน');
                    }
                    $change = -$qty;    // ตัดสต็อกอีกครั้ง
                    $type = 'sale';
                    $note = 'เปิดออเดอร์ #' . $id . ' กลับมาใช้งาน';
                }
                $u = $conn->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
                $u->bind_param('ii', $change, $pid);
                $u->execute();
                log_stock($conn, $pid, $change, $type, $note);
            }
        }

        $stmt = $conn->prepare('UPDATE orders SET status = ? WHERE id = ?');
        $stmt->bind_param('si', $newStatus, $id);
        $stmt->execute();

        $conn->commit();
        flash('อัปเดตสถานะออเดอร์เรียบร้อยแล้ว' . ($toCancel ? ' (คืนสต็อกให้แล้ว)' : ''));
    } catch (RuntimeException $ex) {
        $conn->rollback();
        flash($ex->getMessage(), 'error');
    } catch (Throwable $ex) {
        $conn->rollback();
        flash('อัปเดตสถานะไม่สำเร็จ', 'error');
    }
    redirect('order_view.php?id=' . $id);
}

$stmt = $conn->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) {
    flash('ไม่พบคำสั่งซื้อ', 'error');
    redirect('orders.php');
}

$stmt = $conn->prepare(
    'SELECT oi.quantity, oi.price, p.name, p.brand
     FROM order_items oi JOIN products p ON p.id = oi.product_id
     WHERE oi.order_id = ?'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$pageTitle = 'ออเดอร์ #' . $id;
$activeNav = 'orders';
require __DIR__ . '/_header.php';
?>

<div class="toolbar">
    <h1 style="margin:0">ออเดอร์ #<?= (int)$order['id'] ?></h1>
    <a class="btn btn-outline" href="orders.php">&larr; กลับรายการ</a>
</div>

<div class="checkout-layout">
    <div>
        <div class="table-wrap">
        <table>
            <thead><tr><th>สินค้า</th><th class="num">ราคา/ชิ้น</th><th class="num">จำนวน</th><th class="num">รวม</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr>
                    <td><strong><?= e($it['name']) ?></strong><br><small style="color:var(--muted)"><?= e($it['brand']) ?></small></td>
                    <td class="num"><?= money($it['price']) ?></td>
                    <td class="num"><?= (int)$it['quantity'] ?></td>
                    <td class="num"><?= money($it['price'] * $it['quantity']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="cart-summary">ยอดรวม: <strong><?= money($order['total_price']) ?></strong></p>
    </div>

    <div class="form-box">
        <h3 style="margin-top:0">ข้อมูลลูกค้า</h3>
        <p><strong><?= e($order['customer_name']) ?></strong><br>
           โทร: <?= e($order['phone']) ?><br>
           <?= nl2br(e($order['address'])) ?></p>
        <p style="color:var(--muted)">สั่งเมื่อ <?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?></p>

        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
            <label for="status">สถานะออเดอร์</label>
            <select id="status" name="status">
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= e($key) ?>" <?= $order['status'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <small style="color:var(--muted)">เลือก "ยกเลิก" ระบบจะคืนสต็อกและบันทึกประวัติให้อัตโนมัติ</small>
            <p style="margin-top:16px"><button class="btn" type="submit">บันทึกสถานะ</button></p>
        </form>
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
