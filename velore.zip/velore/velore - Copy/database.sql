-- =====================================================
-- VELORE : ระบบร้านค้าออนไลน์น้ำหอมนำเข้า (เวอร์ชัน 2)
-- สำหรับติดตั้งใหม่: เปิด http://localhost/VELORE/install.php
--   หรือ phpMyAdmin > Import > เลือกไฟล์นี้ > Go
-- สำหรับฐานข้อมูลเดิม (เวอร์ชัน 1): เปิด http://localhost/VELORE/upgrade.php
-- =====================================================

CREATE DATABASE IF NOT EXISTS `VELORE`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `VELORE`;

-- ---------- หมวดหมู่ (แนวกลิ่น) ----------
CREATE TABLE IF NOT EXISTS `categories` (
  `id`   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_category_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางสินค้า ----------
CREATE TABLE IF NOT EXISTS `products` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(150) NOT NULL,
  `brand`       VARCHAR(100) NOT NULL,
  `category_id` INT UNSIGNED DEFAULT NULL,
  `scent_notes` VARCHAR(255) DEFAULT NULL,
  `price`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `stock`       INT NOT NULL DEFAULT 0,
  `image`       VARCHAR(255) DEFAULT NULL,
  `description` TEXT,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางออเดอร์ ----------
CREATE TABLE IF NOT EXISTS `orders` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_name` VARCHAR(150) NOT NULL,
  `phone`         VARCHAR(20)  NOT NULL,
  `address`       TEXT NOT NULL,
  `total_price`   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status`        ENUM('pending','paid','shipped','completed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางรายการสินค้าในออเดอร์ ----------
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id`   INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `quantity`   INT NOT NULL DEFAULT 1,
  `price`      DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_product` (`product_id`),
  CONSTRAINT `fk_items_order`   FOREIGN KEY (`order_id`)   REFERENCES `orders`(`id`)   ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ประวัติการเปลี่ยนแปลงสต็อก ----------
-- change_amount: บวก = เพิ่มสต็อก, ลบ = ลดสต็อก
CREATE TABLE IF NOT EXISTS `stock_logs` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id`    INT UNSIGNED NOT NULL,
  `change_amount` INT NOT NULL,
  `type`          ENUM('add','remove','adjust','sale','cancel') NOT NULL,
  `note`          VARCHAR(255) DEFAULT NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_product` (`product_id`),
  KEY `idx_log_created` (`created_at`),
  CONSTRAINT `fk_logs_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางผู้ดูแลระบบ ----------
CREATE TABLE IF NOT EXISTS `admins` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(50)  NOT NULL,
  `password`   VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- แอดมินเริ่มต้น: admin / admin123  (bcrypt) *** เปลี่ยนรหัสผ่านที่เมนู "เปลี่ยนรหัสผ่าน" ***
INSERT INTO `admins` (`username`, `password`) VALUES
('admin', '$2y$10$3OWiDHSANmOFfQBL61dWaO.SXdv00FsLrFx5lGvGOp7wFPPQxeXOm');

-- ---------- หมวดหมู่เริ่มต้น ----------
INSERT INTO `categories` (`name`) VALUES ('Woody'), ('Floral'), ('Fresh'), ('Oriental');

-- ---------- สินค้าตัวอย่าง (ไม่มีรูป จะแสดงรูป placeholder) ----------
INSERT INTO `products` (`name`, `brand`, `category_id`, `scent_notes`, `price`, `stock`, `image`, `description`) VALUES
('Sauvage Eau de Parfum', 'Dior', (SELECT id FROM categories WHERE name='Woody'), 'Bergamot, Pepper, Ambroxan, Vanilla', 4200.00, 15, 'sauvage.svg', 'น้ำหอมสำหรับผู้ชาย กลิ่นสดคมผสานความอบอุ่นของไม้และวานิลลา ติดทนนาน'),
('Terre d''Hermès', 'Hermès', (SELECT id FROM categories WHERE name='Woody'), 'Orange, Flint, Vetiver, Cedar', 3900.00, 10, 'terre.svg', 'กลิ่นส้มสดผสานกลิ่นแร่และเวติเวอร์ สะท้อนความเป็นธรรมชาติ'),
('Chance Eau Tendre', 'Chanel', (SELECT id FROM categories WHERE name='Floral'), 'Grapefruit, Quince, Jasmine, White Musk', 4800.00, 8, 'chance.svg', 'กลิ่นดอกไม้ผลไม้อ่อนหวาน ละมุน เหมาะกับทุกวัน'),
('J''adore', 'Dior', (SELECT id FROM categories WHERE name='Floral'), 'Ylang-Ylang, Rose, Jasmine, Musk', 5200.00, 12, 'jadore.svg', 'ช่อดอกไม้หรูหราสำหรับผู้หญิง สง่างามและทันสมัย'),
('Acqua di Giò', 'Giorgio Armani', (SELECT id FROM categories WHERE name='Fresh'), 'Marine Notes, Lime, Rosemary, Cedar', 3300.00, 20, 'acqua.svg', 'กลิ่นทะเลสดชื่น ให้ความรู้สึกโปร่งเบาและสะอาด'),
('Light Blue', 'Dolce & Gabbana', (SELECT id FROM categories WHERE name='Fresh'), 'Lemon, Apple, Cedar, Musk', 3100.00, 18, 'lightblue.svg', 'กลิ่นซิตรัสฤดูร้อน สดใส สบาย เหมาะกับอากาศร้อน'),
('Black Opium', 'Yves Saint Laurent', (SELECT id FROM categories WHERE name='Oriental'), 'Coffee, Vanilla, White Flowers, Patchouli', 4600.00, 9, 'blackopium.svg', 'กลิ่นกาแฟผสมวานิลลา หวานลึกลับ เย้ายวน'),
('Shalimar', 'Guerlain', (SELECT id FROM categories WHERE name='Oriental'), 'Bergamot, Iris, Vanilla, Tonka Bean', 5600.00, 5, 'shalimar.svg', 'น้ำหอมออเรียนทัลระดับตำนาน กลิ่นอบอุ่นหรูหราและหนักแน่น');

-- บันทึกสต็อกตั้งต้นของสินค้าตัวอย่าง
INSERT INTO `stock_logs` (`product_id`, `change_amount`, `type`, `note`)
SELECT id, stock, 'add', 'สต็อกตั้งต้น' FROM products;
