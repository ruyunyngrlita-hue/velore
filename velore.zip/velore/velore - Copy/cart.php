<?php
require_once __DIR__ . '/includes/config.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ---------- จัดการ action (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['product_id'] ?? 0);

    // เช็คสต็อกของสินค้า
    $stock = null;
    if ($pid > 0) {
        $stmt = $conn->prepare('SELECT stock FROM products WHERE id = ?');
        $stmt->bind_param('i', $pid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stock = $row ? (int)$row['stock'] : null;
    }

    switch ($action) {
        case 'add':
            if ($stock === null || $stock < 1) {
                flash('ไม่พบสินค้าหรือสินค้าหมด', 'error');
                break;
            }
            $qty = max(1, (int)($_POST['quantity'] ?? 1));
            $new = ($_SESSION['cart'][$pid] ?? 0) + $qty;
            if ($new > $stock) {
                $new = $stock;
                flash('จำนวนสินค้าถูกปรับตามสต็อกที่มีอยู่', 'error');
            } else {
                flash('เพิ่มสินค้าลงตะกร้าแล้ว');
            }
            $_SESSION['cart'][$pid] = $new;
            break;

        case 'update':
            $qty = (int)($_POST['quantity'] ?? 0);
            if ($qty <= 0) {
                unset($_SESSION['cart'][$pid]);
                flash('นำสินค้าออกจากตะกร้าแล้ว');
            } elseif ($stock !== null) {
                $_SESSION['cart'][$pid] = min($qty, $stock);
                flash('อัปเดตจำนวนสินค้าแล้ว');
            }
            break;

        case 'remove':
            unset($_SESSION['cart'][$pid]);
            flash('นำสินค้าออกจากตะกร้าแล้ว');
            break;
    }

    // กลับหน้าก่อนหน้า (ถ้าเพิ่มสินค้า) หรือกลับตะกร้า
    if ($action === 'add' && !empty($_SERVER['HTTP_REFERER'])) {
        $ref = $_SERVER['HTTP_REFERER'];
        $host = parse_url($ref, PHP_URL_HOST);
        if ($host === ($_SERVER['SERVER_NAME'] ?? '') || $host === ($_SERVER['HTTP_HOST'] ?? '')) {
            redirect($ref);
        }
    }
    redirect('cart.php');
}

// ---------- ดึงข้อมูลสินค้าในตะกร้า ----------
$items = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($p = $res->fetch_assoc()) {
        $p['qty']      = $_SESSION['cart'][$p['id']];
        $p['subtotal'] = $p['qty'] * $p['price'];
        $total += $p['subtotal'];
        $items[] = $p;
    }
}

$pageTitle = 'ตะกร้าสินค้า';
require __DIR__ . '/includes/header.php';
?>

<h1>ตะกร้าสินค้า</h1>

<?php if (!$items): ?>
    <p>ตะกร้าของคุณยังว่างอยู่ <a href="index.php">เลือกซื้อสินค้า</a></p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>สินค้า</th>
                <th class="num">ราคา</th>
                <th>จำนวน</th>
                <th class="num">รวม</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $it): ?>
            <tr>
                <td>
                    <div style="display:flex;gap:12px;align-items:center">
                        <?= product_img_tag($it, $it['name'], 'thumb') ?>
                        <div>
                            <strong><?= e($it['name']) ?></strong><br>
                            <small style="color:var(--muted)"><?= e($it['brand']) ?></small>
                        </div>
                    </div>
                </td>
                <td class="num"><?= money($it['price']) ?></td>
                <td>
                    <form method="post" action="cart.php" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="product_id" value="<?= (int)$it['id'] ?>">
                        <input class="qty-input" type="number" name="quantity" value="<?= (int)$it['qty'] ?>" min="0" max="<?= (int)$it['stock'] ?>">
                        <button class="btn btn-sm btn-outline" type="submit">อัปเดต</button>
                    </form>
                </td>
                <td class="num"><?= money($it['subtotal']) ?></td>
                <td>
                    <form method="post" action="cart.php" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="product_id" value="<?= (int)$it['id'] ?>">
                        <button class="btn btn-sm btn-danger" type="submit">ลบ</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="cart-summary">
        ยอดรวมทั้งหมด: <strong><?= money($total) ?></strong>
        <div style="margin-top:14px">
            <a class="btn btn-outline" href="index.php">เลือกสินค้าต่อ</a>
            <a class="btn" href="checkout.php">ดำเนินการสั่งซื้อ</a>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
