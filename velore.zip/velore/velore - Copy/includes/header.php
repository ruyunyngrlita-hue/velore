<?php
require_once __DIR__ . '/config.php';
$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME . ' - น้ำหอมนำเข้า';
$metaDesc  = $metaDesc ?? 'VELORE ร้านน้ำหอมนำเข้าแท้ เลือกซื้อออนไลน์ได้ง่าย';
$searchQ   = trim($_GET['q'] ?? '');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($metaDesc) ?>">
    <meta property="og:title" content="<?= e($pageTitle) ?>">
    <meta property="og:description" content="<?= e($metaDesc) ?>">
    <link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>/assets/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Noto+Sans+Thai:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="topbar">น้ำหอมนำเข้าแท้ · สั่งซื้อออนไลน์ ทางร้านติดต่อกลับเพื่อยืนยันการชำระเงินและจัดส่ง</div>
<header class="site-header">
    <div class="container header-inner">
        <a class="logo" href="<?= BASE_URL ?>/index.php">VELORE</a>
        <form class="header-search" method="get" action="<?= BASE_URL ?>/index.php" role="search">
            <label for="hs" class="sr">ค้นหาน้ำหอม</label>
            <input id="hs" type="search" name="q" value="<?= e($searchQ) ?>" placeholder="ค้นหาชื่อ / แบรนด์ / โน้ตกลิ่น">
            <button type="submit" aria-label="ค้นหา">ค้นหา</button>
        </form>
        <a class="cart-link" href="<?= BASE_URL ?>/cart.php">ตะกร้า <span class="cart-badge"><?= cart_count() ?></span></a>
    </div>
    <nav class="main-nav-bar">
        <div class="container main-nav">
            <a href="<?= BASE_URL ?>/index.php">ทั้งหมด</a>
            <?php foreach (get_categories($conn) as $cat): ?>
                <a href="<?= BASE_URL ?>/index.php?cat=<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></a>
            <?php endforeach; ?>
        </div>
    </nav>
</header>
<main class="container">
<?= flash() ?>
