</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <p class="logo-small">VELORE</p>
            <p>น้ำหอมนำเข้า คัดสรรกลิ่นระดับโลก</p>
        </div>
        <div>
            <strong>แนวกลิ่น</strong>
            <?php foreach (get_categories($conn) as $cat): ?>
                <a href="<?= BASE_URL ?>/index.php?cat=<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></a>
            <?php endforeach; ?>
        </div>
        <div>
            <strong>เมนู</strong>
            <a href="<?= BASE_URL ?>/index.php">สินค้าทั้งหมด</a>
            <a href="<?= BASE_URL ?>/cart.php">ตะกร้าสินค้า</a>
            <a href="<?= BASE_URL ?>/admin/login.php">สำหรับผู้ดูแลระบบ</a>
        </div>
    </div>
    <p class="copyright">&copy; <?= date('Y') ?> VELORE. All rights reserved.</p>
</footer>
</body>
</html>
