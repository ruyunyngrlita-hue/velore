<?php
// =====================================================
// VELORE - ไฟล์ตั้งค่าหลัก (เชื่อมต่อฐานข้อมูล + ฟังก์ชันช่วยเหลือ)
// =====================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- ตั้งค่าฐานข้อมูล (XAMPP ค่าเริ่มต้น) ----
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);   // ถ้า XAMPP ของคุณใช้พอร์ตอื่น (เช่น 3307) ให้แก้ตรงนี้
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'VELORE');

// ---- ตั้งค่าเว็บ ----
define('SITE_NAME', 'VELORE');
require_once __DIR__ . '/images.php';
// BASE_URL หาให้อัตโนมัติจากตำแหน่งโฟลเดอร์ (เช่น /VELORE) ถ้าต้องการกำหนดเอง ให้แก้เป็น define('BASE_URL', '/ชื่อโฟลเดอร์');
define('BASE_URL', detect_base_url(
    (string)realpath(__DIR__ . '/..'),
    (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? '')
));
define('UPLOAD_DIR', __DIR__ . '/../uploads/');         // ที่เก็บรูปจริงบนดิสก์
define('UPLOAD_URL', BASE_URL . '/uploads/');           // URL ของรูป
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024);             // 2MB
define('LOW_STOCK', 5);                                 // สต็อกที่ถือว่า "ใกล้หมด"

date_default_timezone_set('Asia/Bangkok');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+07:00'");   // ให้เวลาในฐานข้อมูลตรงกับเวลาไทย
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die('ไม่สามารถเชื่อมต่อฐานข้อมูลได้ กรุณาตรวจสอบ includes/config.php และว่าได้ import database.sql แล้ว<br><br>'
      . '<strong>รายละเอียดข้อผิดพลาด:</strong> ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
      . '<br><small>(ลบส่วนแสดงรายละเอียดนี้ออกเมื่อขึ้นเว็บจริง)</small>');
}

// ---- ตรวจว่าฐานข้อมูลติดตั้ง/อัปเกรดครบหรือยัง (ผลถูกจำใน session จะไม่ตรวจซ้ำทุกหน้า) ----
if (!defined('VELORE_SKIP_SCHEMA_CHECK') && empty($_SESSION['schema_ok'])) {
    $need = ['products', 'orders', 'order_items', 'admins', 'categories', 'stock_logs'];
    $have = [];
    $res = $conn->query('SHOW TABLES');
    while ($row = $res->fetch_row()) {
        $have[] = strtolower($row[0]);
    }
    $missing = array_diff($need, $have);
    if ($missing) {
        http_response_code(500);
        die('ฐานข้อมูล VELORE ยังไม่ครบ (ขาดตาราง: ' . htmlspecialchars(implode(', ', $missing), ENT_QUOTES, 'UTF-8') . ')<br><br>'
          . 'ติดตั้งใหม่: เปิด <a href="' . BASE_URL . '/install.php">install.php</a> (ถ้าฐานข้อมูล VELORE ว่างเปล่าให้ลบฐานข้อมูลนี้ใน phpMyAdmin ก่อน)<br>'
          . 'หรือถ้าเคยติดตั้งเวอร์ชันเก่าไว้แล้ว: เปิด <a href="' . BASE_URL . '/upgrade.php">upgrade.php</a>');
    }
    $_SESSION['schema_ok'] = true;
}

// ---- ฟังก์ชันช่วยเหลือ ----
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function money($n) {
    return '฿' . number_format((float)$n, 2);
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// คงไว้เพื่อความเข้ากันได้กับโค้ดเดิม (ใช้ product_image_url($product) แทนได้)
function product_image($filename) {
    return product_image_url(['image' => $filename]);
}

// ---- CSRF ----
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check() {
    $ok = isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(400);
        die('คำขอไม่ถูกต้อง (CSRF) กรุณารีเฟรชหน้าแล้วลองใหม่');
    }
}

// ---- Flash message ----
function flash($msg = null, $type = 'success') {
    if ($msg !== null) {
        $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
        return;
    }
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return '<div class="alert alert-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    return '';
}

// ---- ตะกร้าสินค้า (เก็บใน session: [product_id => quantity]) ----
function cart_count() {
    return isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
}

// ---- สถานะออเดอร์ ----
function order_statuses() {
    return [
        'pending'   => 'รอชำระเงิน',
        'paid'      => 'ชำระเงินแล้ว',
        'shipped'   => 'จัดส่งแล้ว',
        'completed' => 'สำเร็จ',
        'cancelled' => 'ยกเลิก',
    ];
}

// สถานะที่นับเป็นยอดขายจริง (ไม่รวมรอชำระเงินและยกเลิก)
function sales_statuses_sql() {
    return "'paid','shipped','completed'";
}

// ---- หมวดหมู่ (แนวกลิ่น) ----
function get_categories(mysqli $conn) {
    return $conn->query('SELECT id, name FROM categories ORDER BY name')->fetch_all(MYSQLI_ASSOC);
}

// ---- บันทึกประวัติสต็อก (เรียกภายใน transaction ที่ปรับ products.stock แล้ว) ----
// $change: บวก = เพิ่ม, ลบ = ลด   $type: add|remove|adjust|sale|cancel
function log_stock(mysqli $conn, int $productId, int $change, string $type, ?string $note = null) {
    $stmt = $conn->prepare('INSERT INTO stock_logs (product_id, change_amount, type, note) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('iiss', $productId, $change, $type, $note);
    $stmt->execute();
}
