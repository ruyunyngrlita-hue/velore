<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/card.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();

if (!$p) {
    http_response_code(404);
    $pageTitle = 'ไม่พบสินค้า';
    require __DIR__ . '/includes/header.php';
    echo '<div class="empty-state"><p>ไม่พบสินค้าที่ต้องการ</p><a class="btn btn-outline" href="index.php">กลับหน้าแรก</a></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

// สินค้าที่เกี่ยวข้อง (หมวดเดียวกัน ไม่รวมตัวเอง สูงสุด 4 รายการ)
$related = [];
if ($p['category_id']) {
    $stmt = $conn->prepare(
        'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.category_id = ? AND p.id <> ? ORDER BY p.stock > 0 DESC, p.id DESC LIMIT 4'
    );
    $stmt->bind_param('ii', $p['category_id'], $id);
    $stmt->execute();
    $related = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$stock = (int)$p['stock'];
$pageTitle = $p['name'] . ' - ' . $p['brand'];
$metaDesc = mb_substr(trim(($p['description'] ?: ($p['brand'] . ' ' . $p['name'])) . ' โน้ตกลิ่น: ' . $p['scent_notes']), 0, 150);
require __DIR__ . '/includes/header.php';
?>

<nav class="breadcrumb" aria-label="breadcrumb">
    <a href="index.php">หน้าแรก</a> ›
    <?php if ($p['category_name']): ?>
        <a href="index.php?cat=<?= (int)$p['category_id'] ?>"><?= e($p['category_name']) ?></a> ›
    <?php endif; ?>
    <span><?= e($p['name']) ?></span>
</nav>

<div class="two-col product-detail">
    <div class="product-photo">
        <?= product_img_tag($p, $p['name'], '', false) ?>
    </div>
    <div>
        <span class="brand-line"><?= e($p['brand']) ?></span>
        <h1><?= e($p['name']) ?></h1>
        <?php if ($p['category_name']): ?>
            <p><a class="chip" href="index.php?cat=<?= (int)$p['category_id'] ?>">แนว <?= e($p['category_name']) ?></a></p>
        <?php endif; ?>
        <p class="detail-price"><?= money($p['price']) ?></p>

        <?php if ($stock <= 0): ?>
            <p class="stock-line stock-out">สินค้าหมด</p>
        <?php elseif ($stock <= LOW_STOCK): ?>
            <p class="stock-line stock-low">เหลือเพียง <?= $stock ?> ชิ้น</p>
        <?php else: ?>
            <p class="stock-line stock-ok">มีสินค้าพร้อมส่ง</p>
        <?php endif; ?>

        <?php if ($stock > 0): ?>
            <form method="post" action="cart.php" class="buy-form">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                <label for="qty">จำนวน</label>
                <input class="qty-input" id="qty" type="number" name="quantity" value="1" min="1" max="<?= $stock ?>">
                <button class="btn" type="submit">เพิ่มลงตะกร้า</button>
            </form>
        <?php else: ?>
            <button class="btn" type="button" disabled>สินค้าหมด</button>
        <?php endif; ?>

        <?php if ($p['scent_notes']): ?>
            <h3 class="detail-h">โน้ตกลิ่น</h3>
            <p class="note-tags">
                <?php foreach (array_filter(array_map('trim', explode(',', $p['scent_notes']))) as $note): ?>
                    <span class="tag"><?= e($note) ?></span>
                <?php endforeach; ?>
            </p>
        <?php endif; ?>

        <?php if ($p['description']): ?>
            <h3 class="detail-h">รายละเอียด</h3>
            <p><?= nl2br(e($p['description'])) ?></p>
        <?php endif; ?>
    </div>
</div>

<?php if ($related): ?>
    <h2>น้ำหอมแนวเดียวกัน</h2>
    <div class="grid">
        <?php foreach ($related as $r) echo product_card($r); ?>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
