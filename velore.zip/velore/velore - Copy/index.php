<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/card.php';

$categories = get_categories($conn);
$selected = (int)($_GET['cat'] ?? 0);
if (!in_array($selected, array_map('intval', array_column($categories, 'id')), true)) {
    $selected = 0;
}
$q = trim($_GET['q'] ?? '');

$sortOptions = [
    'new'        => ['สินค้ามาใหม่', 'p.id DESC'],
    'price_asc'  => ['ราคา: ต่ำ → สูง', 'p.price ASC, p.id DESC'],
    'price_desc' => ['ราคา: สูง → ต่ำ', 'p.price DESC, p.id DESC'],
    'name'       => ['ชื่อ A → Z', 'p.name ASC'],
];
$sort = $_GET['sort'] ?? 'new';
if (!isset($sortOptions[$sort])) $sort = 'new';

// ---------- ดึงสินค้า ----------
$where = [];
$types = '';
$params = [];
if ($selected > 0) {
    $where[] = 'p.category_id = ?';
    $types .= 'i';
    $params[] = $selected;
}
if ($q !== '') {
    $where[] = '(p.name LIKE ? OR p.brand LIKE ? OR p.scent_notes LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'sss';
    array_push($params, $like, $like, $like);
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$grouped = ($selected === 0 && $q === '' && $sort === 'new');   // หน้าแรกปกติ: แยกกลุ่มตามหมวด
$orderSql = $grouped ? 'c.name IS NULL, c.name, p.id DESC' : $sortOptions[$sort][1];

$stmt = $conn->prepare(
    "SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON c.id = p.category_id $whereSql ORDER BY $orderSql"
);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$selectedName = '';
foreach ($categories as $c) {
    if ((int)$c['id'] === $selected) $selectedName = $c['name'];
}

$pageTitle = $selectedName !== '' ? "น้ำหอมแนว $selectedName" : ($q !== '' ? "ค้นหา: $q" : 'น้ำหอมนำเข้า');
$metaDesc = 'VELORE ร้านน้ำหอมนำเข้า คัดสรรกลิ่นระดับโลก แยกตามแนวกลิ่น Woody, Floral, Fresh, Oriental';
$showHero = ($selected === 0 && $q === '');
require __DIR__ . '/includes/header.php';

function shop_url(array $override = []): string {
    $qs = array_merge($_GET, $override);
    foreach ($qs as $k => $v) if ($v === '' || $v === 0 || $v === '0') unset($qs[$k]);
    return BASE_URL . '/index.php' . ($qs ? '?' . http_build_query($qs) : '');
}
?>

<?php if ($showHero): ?>
<section class="hero-banner">
    <div class="hero-text">
        <span class="hero-kicker">IMPORTED FRAGRANCE</span>
        <h1>กลิ่นที่เป็นคุณ<br>คัดสรรจากทั่วโลก</h1>
        <p>น้ำหอมนำเข้าแท้ เลือกตามแนวกลิ่นที่ใช่ ตั้งแต่ Woody อบอุ่น Floral ละมุน Fresh สดชื่น ไปจนถึง Oriental ลึกลับ</p>
        <a class="btn btn-gold" href="#products">เลือกซื้อเลย</a>
    </div>
    <img class="hero-img" src="<?= BASE_URL ?>/assets/hero-bottle.svg" alt="ขวดน้ำหอม VELORE">
</section>
<section class="trust-strip">
    <div><strong>สินค้านำเข้าแท้</strong><span>คัดสรรก่อนจัดจำหน่าย</span></div>
    <div><strong>แพ็กอย่างดี</strong><span>ห่อกันกระแทกทุกชิ้น</span></div>
    <div><strong>สั่งซื้อง่าย</strong><span>กรอกที่อยู่ ไม่ต้องสมัครสมาชิก</span></div>
    <div><strong>ติดตามออเดอร์</strong><span>ทางร้านติดต่อกลับทางโทรศัพท์</span></div>
</section>
<?php endif; ?>

<div id="products" class="shop-head">
    <div class="filter-bar">
        <a class="chip <?= $selected === 0 ? 'active' : '' ?>" href="<?= e(shop_url(['cat' => 0])) ?>">ทั้งหมด</a>
        <?php foreach ($categories as $c): ?>
            <a class="chip <?= $selected === (int)$c['id'] ? 'active' : '' ?>" href="<?= e(shop_url(['cat' => (int)$c['id']])) ?>"><?= e($c['name']) ?></a>
        <?php endforeach; ?>
    </div>
    <form class="sort-form" method="get" action="<?= BASE_URL ?>/index.php">
        <?php if ($selected): ?><input type="hidden" name="cat" value="<?= (int)$selected ?>"><?php endif; ?>
        <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>
        <label for="sort" class="sr">เรียงตาม</label>
        <select id="sort" name="sort" onchange="this.form.submit()">
            <?php foreach ($sortOptions as $k => [$label]): ?>
                <option value="<?= e($k) ?>" <?= $sort === $k ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <noscript><button class="btn btn-sm" type="submit">เรียง</button></noscript>
    </form>
</div>

<?php if ($q !== ''): ?>
    <p class="result-note">ผลการค้นหา "<strong><?= e($q) ?></strong>" พบ <?= count($products) ?> รายการ
        · <a href="<?= e(shop_url(['q' => ''])) ?>">ล้างคำค้น</a></p>
<?php endif; ?>

<?php if (!$products): ?>
    <div class="empty-state">
        <p>ไม่พบสินค้าที่ตรงกับเงื่อนไข</p>
        <a class="btn btn-outline" href="<?= BASE_URL ?>/index.php">ดูสินค้าทั้งหมด</a>
    </div>
<?php elseif ($grouped): ?>
    <?php
    $groups = [];
    foreach ($products as $p) $groups[$p['category_name'] ?? 'อื่น ๆ'][] = $p;
    foreach ($groups as $groupName => $list): ?>
        <h2><?= e($groupName) ?></h2>
        <div class="grid">
            <?php foreach ($list as $p) echo product_card($p); ?>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="grid">
        <?php foreach ($products as $p) echo product_card($p); ?>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
