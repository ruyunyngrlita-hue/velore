-- =====================================================
-- VELORE : ระบบร้านค้าออนไลน์น้ำหอมนำเข้า (เวอร์ชัน 2)
-- สำหรับติดตั้งใหม่: เปิด http://localhost/VELORE/install.php
--   หรือ phpMyAdmin > Import > เลือกไฟล์นี้ > Go
-- สำหรับฐานข้อมูลเดิม (เวอร์ชัน 1): เปิด http://localhost/VELORE/upgrade.php
-- =====================================================

CREATE DATABASE IF NOT EXISTS `VELORE`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `VELORE`;

-- ---------- หมวดหมู่ (แนวกลิ่น) ----------
CREATE TABLE IF NOT EXISTS `categories` (
  `id`   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_category_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางสินค้า ----------
CREATE TABLE IF NOT EXISTS `products` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(150) NOT NULL,
  `brand`       VARCHAR(100) NOT NULL,
  `category_id` INT UNSIGNED DEFAULT NULL,
  `scent_notes` VARCHAR(255) DEFAULT NULL,
  `price`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `stock`       INT NOT NULL DEFAULT 0,
  `image`       VARCHAR(255) DEFAULT NULL,
  `description` TEXT,
  `description_en` TEXT,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางสมาชิก (ลูกค้า) ----------
CREATE TABLE IF NOT EXISTS `customers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(150) NOT NULL,
  `email`      VARCHAR(150) NOT NULL,
  `password`   VARCHAR(255) NOT NULL,
  `phone`      VARCHAR(20)  NOT NULL DEFAULT '',
  `address`    TEXT,
  `lat`        DECIMAL(10,7) DEFAULT NULL,
  `lng`        DECIMAL(10,7) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางออเดอร์ ----------
-- payment_method: transfer = โอนเงิน, cod = เก็บเงินปลายทาง
-- customer_id ว่างได้ (ออเดอร์เก่าที่สั่งก่อนมีระบบสมาชิก)
CREATE TABLE IF NOT EXISTS `orders` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`    INT UNSIGNED DEFAULT NULL,
  `customer_name`  VARCHAR(150) NOT NULL,
  `phone`          VARCHAR(20)  NOT NULL,
  `address`        TEXT NOT NULL,
  `lat`            DECIMAL(10,7) DEFAULT NULL,
  `lng`            DECIMAL(10,7) DEFAULT NULL,
  `subtotal`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `vat_amount`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_fee`   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_price`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` ENUM('transfer','cod') NOT NULL DEFAULT 'transfer',
  `status`         ENUM('pending','paid','preparing','shipped','completed','cancelled') NOT NULL DEFAULT 'pending',
  `slip_image`     VARCHAR(255) DEFAULT NULL,
  `slip_uploaded_at` DATETIME DEFAULT NULL,
  `shipping_company` VARCHAR(50) DEFAULT NULL,
  `tracking_no`    VARCHAR(100) DEFAULT NULL,
  `shipped_at`     DATETIME DEFAULT NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_status` (`status`),
  KEY `idx_customer` (`customer_id`),
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางรายการสินค้าในออเดอร์ ----------
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id`   INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `quantity`   INT NOT NULL DEFAULT 1,
  `price`      DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_product` (`product_id`),
  CONSTRAINT `fk_items_order`   FOREIGN KEY (`order_id`)   REFERENCES `orders`(`id`)   ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ประวัติการเปลี่ยนแปลงสต็อก ----------
-- change_amount: บวก = เพิ่มสต็อก, ลบ = ลดสต็อก
CREATE TABLE IF NOT EXISTS `stock_logs` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id`    INT UNSIGNED NOT NULL,
  `change_amount` INT NOT NULL,
  `type`          ENUM('add','remove','adjust','sale','cancel') NOT NULL,
  `note`          VARCHAR(255) DEFAULT NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_product` (`product_id`),
  KEY `idx_log_created` (`created_at`),
  CONSTRAINT `fk_logs_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- ตารางผู้ดูแลระบบ ----------
CREATE TABLE IF NOT EXISTS `admins` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(50)  NOT NULL,
  `password`   VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- แอดมินเริ่มต้น: admin / admin123  (bcrypt) *** เปลี่ยนรหัสผ่านที่เมนู "เปลี่ยนรหัสผ่าน" ***
INSERT INTO `admins` (`username`, `password`) VALUES
('admin', '$2y$10$3OWiDHSANmOFfQBL61dWaO.SXdv00FsLrFx5lGvGOp7wFPPQxeXOm');

-- ---------- หมวดหมู่เริ่มต้น ----------
INSERT INTO `categories` (`name`) VALUES ('Woody'), ('Floral'), ('Fresh'), ('Oriental'), ('Citrus');

-- ---------- สินค้าตัวอย่าง (ไม่มีรูป จะแสดงรูป placeholder) ----------
INSERT INTO `products` (`name`, `brand`, `category_id`, `scent_notes`, `price`, `stock`, `image`, `description`) VALUES
('Sauvage Eau de Parfum', 'Dior', (SELECT id FROM categories WHERE name='Woody'), 'Bergamot, Pepper, Ambroxan, Vanilla', 4200.00, 15, 'sauvage.svg', 'น้ำหอมสำหรับผู้ชาย กลิ่นสดคมผสานความอบอุ่นของไม้และวานิลลา ติดทนนาน'),
('Terre d''Hermès', 'Hermès', (SELECT id FROM categories WHERE name='Woody'), 'Orange, Flint, Vetiver, Cedar', 3900.00, 10, 'terre.svg', 'กลิ่นส้มสดผสานกลิ่นแร่และเวติเวอร์ สะท้อนความเป็นธรรมชาติ'),
('Chance Eau Tendre', 'Chanel', (SELECT id FROM categories WHERE name='Floral'), 'Grapefruit, Quince, Jasmine, White Musk', 4800.00, 8, 'chance.svg', 'กลิ่นดอกไม้ผลไม้อ่อนหวาน ละมุน เหมาะกับทุกวัน'),
('J''adore', 'Dior', (SELECT id FROM categories WHERE name='Floral'), 'Ylang-Ylang, Rose, Jasmine, Musk', 5200.00, 12, 'jadore.svg', 'ช่อดอกไม้หรูหราสำหรับผู้หญิง สง่างามและทันสมัย'),
('Acqua di Giò', 'Giorgio Armani', (SELECT id FROM categories WHERE name='Fresh'), 'Marine Notes, Lime, Rosemary, Cedar', 3300.00, 20, 'acqua.svg', 'กลิ่นทะเลสดชื่น ให้ความรู้สึกโปร่งเบาและสะอาด'),
('Light Blue', 'Dolce & Gabbana', (SELECT id FROM categories WHERE name='Fresh'), 'Lemon, Apple, Cedar, Musk', 3100.00, 18, 'lightblue.svg', 'กลิ่นซิตรัสฤดูร้อน สดใส สบาย เหมาะกับอากาศร้อน'),
('Black Opium', 'Yves Saint Laurent', (SELECT id FROM categories WHERE name='Oriental'), 'Coffee, Vanilla, White Flowers, Patchouli', 4600.00, 9, 'blackopium.svg', 'กลิ่นกาแฟผสมวานิลลา หวานลึกลับ เย้ายวน'),
('Shalimar', 'Guerlain', (SELECT id FROM categories WHERE name='Oriental'), 'Bergamot, Iris, Vanilla, Tonka Bean', 5600.00, 5, 'shalimar.svg', 'น้ำหอมออเรียนทัลระดับตำนาน กลิ่นอบอุ่นหรูหราและหนักแน่น'),
('Bleu de Chanel', 'Chanel', (SELECT id FROM categories WHERE name='Woody'), 'Grapefruit, Incense, Cedar, Sandalwood', 4900.00, 11, 'bleu.svg', 'กลิ่นไม้ผสมซิตรัสเข้ม สุขุมและทันสมัย เหมาะกับทุกโอกาส'),
('Angel', 'Mugler', (SELECT id FROM categories WHERE name='Oriental'), 'Caramel, Patchouli, Vanilla, Chocolate', 3800.00, 7, 'angel.svg', 'กลิ่นหวานแบบกูร์มองด์ เอกลักษณ์โดดเด่น ติดทนนาน'),
('Neroli Portofino', 'Tom Ford', (SELECT id FROM categories WHERE name='Citrus'), 'Bergamot, Lemon, Neroli, Amber', 7200.00, 6, 'neroli.svg', 'ซิตรัสสดชื่นแบบริมทะเลเมดิเตอร์เรเนียน หรูและโปร่งเบา'),
('CK One', 'Calvin Klein', (SELECT id FROM categories WHERE name='Citrus'), 'Lemon, Green Tea, Jasmine, Musk', 2400.00, 25, 'ck1.svg', 'ซิตรัสสะอาดสดใส ใช้ได้ทั้งชายและหญิง เหมาะกับทุกวัน');

-- บันทึกสต็อกตั้งต้นของสินค้าตัวอย่าง
-- คำอธิบายภาษาอังกฤษ
UPDATE `products` SET `description_en`='A fresh, bold men''s fragrance blending the warmth of woods with vanilla. Long lasting.' WHERE `name`='Sauvage Eau de Parfum';
UPDATE `products` SET `description_en`='Fresh orange meets mineral flint and vetiver, a fragrance inspired by nature.' WHERE `name`='Terre d''Hermès';
UPDATE `products` SET `description_en`='A soft, fruity-floral scent that is gentle and easy to wear every day.' WHERE `name`='Chance Eau Tendre';
UPDATE `products` SET `description_en`='A luxurious bouquet of flowers for women. Elegant and modern.' WHERE `name`='J''adore';
UPDATE `products` SET `description_en`='A fresh marine scent that feels light, airy and clean.' WHERE `name`='Acqua di Giò';
UPDATE `products` SET `description_en`='A bright summer citrus fragrance, cheerful and comfortable in hot weather.' WHERE `name`='Light Blue';
UPDATE `products` SET `description_en`='Coffee and vanilla in a sweet, mysterious and seductive scent.' WHERE `name`='Black Opium';
UPDATE `products` SET `description_en`='A legendary oriental fragrance, warm, luxurious and rich.' WHERE `name`='Shalimar';
UPDATE `products` SET `description_en`='A woody-citrus fragrance that is calm, refined and modern. Suits any occasion.' WHERE `name`='Bleu de Chanel';
UPDATE `products` SET `description_en`='A gourmand sweet scent with a distinctive signature. Long lasting.' WHERE `name`='Angel';
UPDATE `products` SET `description_en`='Fresh Mediterranean-coast citrus, luxurious yet light.' WHERE `name`='Neroli Portofino';
UPDATE `products` SET `description_en`='A clean, bright citrus for men and women, easy to wear every day.' WHERE `name`='CK One';

INSERT INTO `stock_logs` (`product_id`, `change_amount`, `type`, `note`)
SELECT id, stock, 'add', 'สต็อกตั้งต้น' FROM products;
