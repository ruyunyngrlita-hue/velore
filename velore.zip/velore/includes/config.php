<?php
// =====================================================
// VELORE - ไฟล์ตั้งค่าหลัก (เชื่อมต่อฐานข้อมูล + ฟังก์ชันช่วยเหลือ)
// =====================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- ตั้งค่าฐานข้อมูล (XAMPP ค่าเริ่มต้น) ----
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);   // ถ้า XAMPP ของคุณใช้พอร์ตอื่น (เช่น 3307) ให้แก้ตรงนี้
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'VELORE');

// ---- ตั้งค่าเว็บ ----
define('SITE_NAME', 'VELORE');
require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/images.php';
require_once __DIR__ . '/customer_auth.php';
require_once __DIR__ . '/courier.php';
require_once __DIR__ . '/promptpay.php';
// BASE_URL หาให้อัตโนมัติจากตำแหน่งโฟลเดอร์ (เช่น /VELORE) ถ้าต้องการกำหนดเอง ให้แก้เป็น define('BASE_URL', '/ชื่อโฟลเดอร์');
define('BASE_URL', detect_base_url(
    (string)realpath(__DIR__ . '/..'),
    (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? '')
));
define('UPLOAD_DIR', __DIR__ . '/../uploads/');         // ที่เก็บรูปจริงบนดิสก์
define('UPLOAD_URL', BASE_URL . '/uploads/');           // URL ของรูป
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024);             // 2MB
define('LOW_STOCK', 5);                                 // สต็อกที่ถือว่า "ใกล้หมด"

date_default_timezone_set('Asia/Bangkok');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+07:00'");   // ให้เวลาในฐานข้อมูลตรงกับเวลาไทย
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die('ไม่สามารถเชื่อมต่อฐานข้อมูลได้ กรุณาตรวจสอบ includes/config.php และว่าได้ import database.sql แล้ว<br><br>'
      . '<strong>รายละเอียดข้อผิดพลาด:</strong> ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
      . '<br><small>(ลบส่วนแสดงรายละเอียดนี้ออกเมื่อขึ้นเว็บจริง)</small>');
}

// ---- ตรวจว่าฐานข้อมูลติดตั้ง/อัปเกรดครบหรือยัง (ผลถูกจำใน session จะไม่ตรวจซ้ำทุกหน้า) ----
if (!defined('VELORE_SKIP_SCHEMA_CHECK') && empty($_SESSION['schema_ok'])) {
    $need = ['products', 'orders', 'order_items', 'admins', 'categories', 'stock_logs', 'customers'];
    $have = [];
    $res = $conn->query('SHOW TABLES');
    while ($row = $res->fetch_row()) {
        $have[] = strtolower($row[0]);
    }
    $missing = array_diff($need, $have);
    if ($missing) {
        http_response_code(500);
        die('ฐานข้อมูล VELORE ยังไม่ครบ (ขาดตาราง: ' . htmlspecialchars(implode(', ', $missing), ENT_QUOTES, 'UTF-8') . ')<br><br>'
          . 'ติดตั้งใหม่: เปิด <a href="' . BASE_URL . '/install.php">install.php</a> (ถ้าฐานข้อมูล VELORE ว่างเปล่าให้ลบฐานข้อมูลนี้ใน phpMyAdmin ก่อน)<br>'
          . 'หรือถ้าเคยติดตั้งเวอร์ชันเก่าไว้แล้ว: เปิด <a href="' . BASE_URL . '/upgrade.php">upgrade.php</a>');
    }
    $_SESSION['schema_ok'] = true;
}

// ---- ฟังก์ชันช่วยเหลือ ----
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function money($n) {
    return '฿' . number_format((float)$n, 2);
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// คงไว้เพื่อความเข้ากันได้กับโค้ดเดิม (ใช้ product_image_url($product) แทนได้)
function product_image($filename) {
    return product_image_url(['image' => $filename]);
}

// ---- CSRF ----
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check() {
    $ok = isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(400);
        die('คำขอไม่ถูกต้อง (CSRF) กรุณารีเฟรชหน้าแล้วลองใหม่');
    }
}

// ---- Flash message ----
function flash($msg = null, $type = 'success') {
    if ($msg !== null) {
        $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
        return;
    }
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return '<div class="alert alert-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    return '';
}

// ---- ตะกร้าสินค้า (เก็บใน session: [product_id => quantity]) ----
function cart_count() {
    return isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
}

// ---- สถานะออเดอร์ ----
function order_statuses() {
    return [
        'pending'   => t('st_pending'),
        'paid'      => t('st_paid'),
        'preparing' => t('st_preparing'),
        'shipped'   => t('st_shipped'),
        'completed' => t('st_completed'),
        'cancelled' => t('st_cancelled'),
    ];
}

// สถานะที่นับเป็นยอดขายจริง (ไม่รวมรอชำระเงินและยกเลิก)
function sales_statuses_sql() {
    return "'paid','preparing','shipped','completed'";
}

// ---- วิธีชำระเงิน ----
function payment_methods() {
    return [
        'transfer' => t('pay_transfer'),
        'cod'      => t('pay_cod'),
    ];
}

// ข้อมูลบัญชีรับโอนเงิน (แสดงให้ลูกค้าที่เลือก "โอนเงิน") *** แก้เป็นข้อมูลจริงของร้านก่อนใช้งาน ***
define('BANK_NAME', 'ธนาคาร ........ (แก้ใน includes/config.php)');
define('BANK_ACCOUNT_NO', '000-0-00000-0');
define('BANK_ACCOUNT_NAME', 'ชื่อบัญชี ........');

// ---------- ข้อมูลติดต่อร้าน (แก้เป็นข้อมูลจริงของร้าน) ----------
// ---------- พร้อมเพย์ (QR ให้ลูกค้าสแกนจ่าย) ----------
// ใส่เบอร์โทร 10 หลัก หรือเลขบัตรประชาชน/เลขผู้เสียภาษี 13 หลัก ที่ผูกพร้อมเพย์ของร้าน เว้นว่างไว้ = ไม่แสดง QR
// (ค่าตัวอย่างนี้เป็นเบอร์สมมติ สแกนในแอปธนาคารแล้วจะไม่พบผู้รับ ให้เปลี่ยนเป็นของจริง)
define('PROMPTPAY_ID', '0812345678');
define('PROMPTPAY_NAME', 'VELORE Perfume');   // ชื่อที่แสดงใต้ QR

define('SHOP_PHONE', '081-234-5678');
define('SHOP_EMAIL', 'contact@velore.example');
define('SHOP_ADDRESS', '99/9 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110');
define('SHOP_LINE', '@velore');
define('SHOP_HOURS', 'ทุกวัน 10:00 - 19:00 น.');

// ---------- ภาษี / ค่าจัดส่ง ----------
define('VAT_RATE', 7);               // ภาษีมูลค่าเพิ่ม (%) ใส่ 0 = ไม่คิดภาษี
define('VAT_INCLUDED', false);       // false = ราคาสินค้าเป็นราคาก่อนภาษี (บวกภาษีเพิ่มตอนชำระเงิน)
                                     // true  = ราคาที่แสดงรวมภาษีแล้ว (แยกยอดภาษีให้ดูเฉยๆ)
define('FREE_SHIPPING_MIN', 3000);   // ซื้อครบเท่านี้ (ราคาสินค้า) ส่งฟรี ไม่ว่าจะเลือกขนส่งเจ้าไหน
define('COURIER_STEP_MINUTES', 2);   // *** โหมดสาธิต: สถานะพัสดุเดินหน้าทุกกี่นาที (ตั้ง 240 = ทุก 4 ชั่วโมง สมจริงกว่า) ***

// ---- บริษัทขนส่งพันธมิตร (จำลอง ไม่ได้เชื่อมระบบจริง) ----
// key => [ชื่อ, ลิงก์ติดตาม (%s = เลขพัสดุ), ค่าส่ง(บาท), ระยะเวลา(วัน), รหัสนำหน้าเลขพัสดุ]
function shipping_companies(): array {
    return [
        'flash'    => ['Flash Express',  BASE_URL . '/track.php?no=%s', 40, '1-3', 'TH'],
        'spx'      => ['SPX Express (Shopee)', BASE_URL . '/track.php?no=%s', 35, '2-4', 'SPXTH'],
        'kerry'    => ['Kerry Express',  BASE_URL . '/track.php?no=%s', 55, '1-2', 'KEX'],
        'thaipost' => ['ไปรษณีย์ไทย / Thailand Post', BASE_URL . '/track.php?no=%s', 30, '3-5', 'EP'],
    ];
}
function default_carrier(): string { return 'flash'; }

// คำนวณยอดทั้งหมดจากยอดสินค้า + ขนส่งที่เลือก: [ยอดสินค้า, ภาษี, ค่าส่ง, ยอดรวมที่ต้องชำระ]
function order_totals(float $subtotal, ?string $carrier = null): array {
    $subtotal = round($subtotal, 2);
    if (VAT_INCLUDED) {
        $vat = round($subtotal * VAT_RATE / (100 + VAT_RATE), 2);   // ภาษีที่แฝงอยู่ในราคา
        $payGoods = $subtotal;
    } else {
        $vat = round($subtotal * VAT_RATE / 100, 2);
        $payGoods = $subtotal + $vat;
    }
    $list = shipping_companies();
    $fee = (float)($list[$carrier] ?? $list[default_carrier()])[2];
    $ship = ($subtotal <= 0 || $subtotal >= FREE_SHIPPING_MIN) ? 0.0 : $fee;
    return [$subtotal, $vat, $ship, round($payGoods + $ship, 2)];
}
function tracking_url(?string $company, ?string $no): string {
    $list = shipping_companies();
    if (!$company || !$no || !isset($list[$company])) return '';
    return sprintf($list[$company][1], rawurlencode($no));
}

// ---- สลิปโอนเงิน: เก็บใน uploads/slips/ (ปิดไม่ให้เปิดตรง ดูผ่าน slip.php เท่านั้น) ----
define('SLIP_DIR', UPLOAD_DIR . 'slips/');
function save_slip_upload(array $file, int $orderId): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(($file['error'] ?? 0) === UPLOAD_ERR_NO_FILE ? 'no_file' : 'upload_failed');
    }
    if ($file['size'] > 5 * 1024 * 1024) throw new RuntimeException('too_big');
    $info = @getimagesize($file['tmp_name']);
    $ext = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$info[2] ?? 0] ?? null;
    if (!$ext) throw new RuntimeException('bad_type');
    if (!is_dir(SLIP_DIR) && !mkdir(SLIP_DIR, 0775, true)) throw new RuntimeException('upload_failed');
    if (!is_file(SLIP_DIR . '.htaccess')) {
        @file_put_contents(SLIP_DIR . '.htaccess', "Require all denied\n");
    }
    $name = 'slip-' . $orderId . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], SLIP_DIR . $name)) throw new RuntimeException('upload_failed');
    return $name;
}

// ---- พิกัดแผนที่ (ปักหมุด) ----
function clean_coord($v, float $min, float $max): ?float {
    if ($v === null || $v === '' || !is_numeric($v)) return null;
    $f = (float)$v;
    return ($f >= $min && $f <= $max) ? round($f, 7) : null;
}
function map_link($lat, $lng): string {
    if ($lat === null || $lng === null || $lat === '' || $lng === '') return '';
    return 'https://www.openstreetmap.org/?mlat=' . rawurlencode($lat) . '&mlon=' . rawurlencode($lng) . '#map=17/' . rawurlencode($lat) . '/' . rawurlencode($lng);
}

// ---------- Analytics ----------
// ใส่ Measurement ID ของ Google Analytics 4 (เช่น 'G-XXXXXXXXXX') ระบบจะฝังโค้ดติดตามให้ทุกหน้า
// เว้นว่างไว้ = ยังไม่เปิดใช้
define('GA_MEASUREMENT_ID', '');

// ---- หมวดหมู่ (แนวกลิ่น) ----
function get_categories(mysqli $conn) {
    return $conn->query('SELECT id, name FROM categories ORDER BY name')->fetch_all(MYSQLI_ASSOC);
}

// ---- บันทึกประวัติสต็อก (เรียกภายใน transaction ที่ปรับ products.stock แล้ว) ----
// $change: บวก = เพิ่ม, ลบ = ลด   $type: add|remove|adjust|sale|cancel
function log_stock(mysqli $conn, int $productId, int $change, string $type, ?string $note = null) {
    $stmt = $conn->prepare('INSERT INTO stock_logs (product_id, change_amount, type, note) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('iiss', $productId, $change, $type, $note);
    $stmt->execute();
}
